"""
客户端类
"""
import copy
import torch
import torch.nn as nn
import torchtuples as tt
import numpy as np
from typing import Tuple, Dict, Any
from pycox.models import (
    PCHazard, LogisticHazard, DeepHitSingle,
    CoxPH, CoxTime, CoxCC
)

class Client:
    """客户端类"""
    
    def __init__(self, config, global_model, client_data, client_id):
        """
        初始化客户端
        
        Args:
            config: 联邦学习配置
            global_model: 全局模型
            client_data: 客户端数据
            client_id: 客户端ID
        """
        self.config = config
        self.client_id = client_id
        self.local_model = copy.deepcopy(global_model)
        
        # 确保X和y是numpy数组
        self.X = np.array(client_data[0], dtype=np.float32)
        self.y = np.array(client_data[1], dtype=np.float32)
        self.N = len(self.X)
        
        # 转换标签
        self.client_label_transform()
        
    def client_label_transform(self):
        """标签转换"""
        get_target = lambda df: (df[:, 0], df[:, 1])
        if self.config.model_type in ['PC-Hazard', 'LogisticHazard', 'DeepHit', 'CoxTime']:
            self.labtrans = self.config.labtrans
            self.y = self.labtrans.transform(*get_target(self.y))
        else:
            self.y = get_target(self.y)
            
    def local_train(self, global_model, epoch: int) -> nn.Module:
        """
        本地训练
        
        Args:
            global_model: 全局模型
            epoch: 当前轮次
            
        Returns:
            nn.Module: 训练后的本地模型
        """
        # 更新本地模型
        for name, param in global_model.state_dict().items():
            self.local_model.state_dict()[name].copy_(param.clone())
            
        self.local_model.train()
        
        # 创建优化器
        optimizer = torch.optim.Adam(
            self.local_model.parameters(),
            lr=self.config.learning_rate,
            weight_decay=0.05
        )
        
        # 创建模型
        if self.config.model_type == 'PC-Hazard':
            local_model = PCHazard(self.local_model, optimizer, duration_index=self.labtrans.cuts)
        elif self.config.model_type == 'LogisticHazard':
            local_model = LogisticHazard(self.local_model, optimizer, duration_index=self.labtrans.cuts)
        elif self.config.model_type == 'DeepHit':
            local_model = DeepHitSingle(self.local_model, optimizer, duration_index=self.labtrans.cuts)
        elif self.config.model_type == 'CoxPH':
            local_model = CoxPH(self.local_model, optimizer)
        elif self.config.model_type == 'CoxTime':
            local_model = CoxTime(self.local_model, optimizer, labtrans=self.labtrans)
        elif self.config.model_type == 'CoxCC':
            local_model = CoxCC(self.local_model, optimizer)
        else:
            raise ValueError(f"Unsupported model type: {self.config.model_type}")
            
        # 训练模型
        if self.config.model_type == 'PC-Hazard':
            local_model.fit(
                self.X, self.y,
                epochs=self.config.local_epochs,
                batch_size=self.N,
                verbose=False,
                check_out_features=False
            )
        else:
            local_model.fit(
                self.X, self.y,
                epochs=self.config.local_epochs,
                batch_size=self.N,
                verbose=False
            )
            
        # 返回训练后的模型
        return local_model.net.eval() 