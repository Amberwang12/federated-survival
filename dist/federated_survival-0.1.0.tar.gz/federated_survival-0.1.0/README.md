# Federated Survival Analysis

A federated learning framework for survival analysis, enabling privacy-preserving collaborative learning across multiple institutions while maintaining data confidentiality.

## Features

- **Data Generation and Loading**: Support for both simulated data generation and real-world data loading
- **Data Partitioning**: Tools for splitting data into training and test sets, with training data distributed across federated learning clients
- **Federated Learning**: Implementation of Federated Averaging (FedAvg) algorithm for survival analysis
- **Multiple Models**: Support for various survival analysis models:
  - PC-Hazard
  - LogisticHazard
  - DeepHit
  - CoxPH
  - CoxTime
  - CoxCC
- **Data Augmentation**: Support for client-side data augmentation using MVAEC and MVAES methods
- **Evaluation Metrics**: Comprehensive evaluation including C-index and IBS metrics
- **Training History**: Support for tracking and returning training history

## Installation

You can install the package using pip:

```bash
pip install federated-survival
```

## Usage

### Data Generation and Loading

The framework provides comprehensive tools for generating simulated survival data with various characteristics:

```python
from federated_survival.data.generator import DataGenerator, SimulationConfig

# Configure data generation
sim_config = SimulationConfig(
    n_samples=100,      # Number of samples
    n_features=10,      # Number of features
    censoring_rate=0.2, # Rate of censored observations
    random_state=42     # Random seed for reproducibility
)


# Load real-world data
loader = DataLoader()
data = loader.load("path/to/your/data")


# Generate simulated data
generator = DataGenerator(config=sim_config)

# Generate data with different simulation types:
# 1. Accelerated Failure Time (AFT) Models:
data_weibull = generator.generate('weibull')    # Weibull AFT model
data_lognormal = generator.generate('lognormal') # Lognormal AFT model

# 2. Proportional Hazards Models:
data_sdgm1 = generator.generate('SDGM1')  # Standard proportional hazards
data_sdgm4 = generator.generate('SDGM4')  # Proportional hazards with log-normal errors

# 3. Non-Proportional Hazards Models:
data_sdgm2 = generator.generate('SDGM2')  # Mild violations of proportional hazards
data_sdgm3 = generator.generate('SDGM3')  # Strong violations of proportional hazards
```

The generated data includes:
- Features (x1, x2, ..., xp): Generated with AR(1) covariance structure
- Time: Observed survival/censoring time
- Status: Event indicator (1 = event, 0 = censored)

Each simulation type has different characteristics:
- `weibull`: Weibull AFT model with second half of features relevant
- `lognormal`: Lognormal AFT model with first and last 20% of features relevant
- `SDGM1`: Standard proportional hazards model
- `SDGM2`: Mild violations of proportional hazards with non-linear effects
- `SDGM3`: Strong violations of proportional hazards with shape parameter dependency
- `SDGM4`: Proportional hazards with log-normal errors and covariate-dependent censoring

### Data Partitioning

The framework provides flexible data partitioning methods to simulate various federated learning scenarios:

```python
from federated_survival.data.splitter import DataSplitter

# Initialize splitter with specific configuration
splitter = DataSplitter(
    n_clients=3,           # Number of federated learning clients
    split_type='iid',      # Partition type: 'iid', 'non-iid', 'time-non-iid', 'Dirichlet'
    alpha=0.5,             # Dirichlet distribution parameter for non-IID splitting
    test_size=0.2,         # Proportion of test set
    random_state=42        # Random seed for reproducibility
)

# Split and distribute data to clients
client_data = splitter.split(data)
```

The `split` method returns a `DataSet` object containing:
- `clients_set`: Dictionary of client data, where each client's data is a tuple of (features, labels)
- `test_data`: Test set features
- `test_label`: Test set labels (time and status)
- `raw_aug_clients_set`: Placeholder for augmented client data

#### Available Partition Types

1. **IID (Independent and Identically Distributed)**
   - Ensures each client has the same censoring rate
   - Data is stratified by censoring status before splitting
   - Suitable for simulating ideal federated learning scenarios

2. **Non-IID (Non-Independent and Identically Distributed)**
   - Randomly splits data without maintaining censoring rate balance
   - Simulates scenarios where clients have different data distributions
   - Useful for testing model robustness

3. **Time-Non-IID**
   - Splits data based on survival time ranges
   - Maintains censoring status balance within each time range
   - Simulates scenarios where clients have different time distributions
   - Useful for testing temporal distribution shifts

4. **Dirichlet (Experimental)**
   - Uses Dirichlet distribution to create non-IID splits
   - Considers feature values when assigning samples to clients
   - Allows control over the degree of non-IID through alpha parameter
   - Useful for creating complex non-IID scenarios

#### Data Structure

The partitioned data follows this structure:
- Features (X): numpy array of shape (n_samples, n_features)
- Labels (y): numpy array of shape (n_samples, 2)
  - First column: survival/censoring time
  - Second column: event indicator (1 = event, 0 = censored)

### Federated Learning

The framework implements Federated Averaging (FedAvg) algorithm for survival analysis with support for multiple survival models:

```python
from federated_survival.core.runner import FSARunner
from federated_survival.core.config import FSAConfig

# Configure the federated learning process
config = FSAConfig(
    num_clients=3,           # Number of federated learning clients
    n_features=10,           # Number of features
    n_samples=100,           # Number of samples
    censor_rate=0.3,         # Censoring rate
    model_type='PC-Hazard',  # Survival model type
    local_epochs=2,          # Number of local training epochs
    global_epochs=2,         # Number of global communication rounds
    learning_rate=0.01,      # Learning rate
    batch_size=32,           # Batch size
    random_seed=42,          # Random seed
    client_sample_ratio=0.5, # Ratio of clients selected in each round
    early_stopping=True,     # Enable early stopping
    early_stopping_patience=5 # Number of epochs to wait before early stopping
)

# Initialize and run the federated learning process
runner = FSARunner(config)
results = runner.run(client_data)

# Access evaluation metrics
train_cindex = results['train_Cindex']
train_ibs = results['train_IBS']
test_cindex = results['test_Cindex']
test_ibs = results['test_IBS']
```

#### Available Survival Models

1. **PC-Hazard**
   - Piecewise constant hazard model
   - Discretizes time into intervals
   - Suitable for general survival analysis tasks
   - Uses quantile-based time discretization

2. **LogisticHazard**
   - Logistic regression-based hazard model
   - Similar to PC-Hazard but with logistic activation
   - Better for modeling smooth hazard functions
   - Uses quantile-based time discretization

3. **DeepHit**
   - Deep learning-based survival model
   - Can capture complex non-linear relationships
   - Handles competing risks
   - Uses quantile-based time discretization

4. **CoxPH**
   - Traditional Cox proportional hazards model
   - Assumes proportional hazards
   - No time discretization needed
   - Good baseline model

5. **CoxTime**
   - Time-dependent Cox model
   - Allows time-varying effects
   - More flexible than CoxPH
   - No time discretization needed

6. **CoxCC**
   - Case-control Cox model
   - Efficient for large datasets
   - Suitable for matched case-control studies
   - No time discretization needed

#### Training Process

1. **Initialization**
   - Set random seeds for reproducibility
   - Initialize global model at server
   - Create client models with local data

2. **Federated Training**
   - For each global epoch:
     - Select a subset of clients (controlled by client_sample_ratio)
     - Each selected client performs local training
     - Clients send model updates to server
     - Server aggregates updates using FedAvg
     - Update global model

3. **Model Evaluation**
   - Track training metrics (C-index and IBS)
   - Evaluate on test set
   - Support for early stopping
   - Visualization of training progress

#### Evaluation Metrics

1. **C-index (Concordance Index)**
   - Measures model's ability to correctly rank survival times
   - Range: 0.5 (random) to 1.0 (perfect)
   - Higher values indicate better performance

2. **IBS (Integrated Brier Score)**
   - Measures accuracy of predicted survival probabilities
   - Range: 0.0 (perfect) to 0.25 (worst)
   - Lower values indicate better performance

#### Visualization

```python
# Plot training results
runner.plot_results(
    raw_results=results,          # Results from raw data
)
```

The plot shows:
- C-index over training epochs
- IBS over training epochs
- C-index over test epochs
- IBS over test epochs

### Data Augmentation

The framework provides two advanced data augmentation methods for survival analysis in federated learning:

```python
from federated_survival.core.runner import FSARunner
from federated_survival.core.config import FSAConfig

# Configure the federated learning process with augmentation
config = FSAConfig(
    num_clients=3,
    n_features=10,
    n_samples=100,
    censor_rate=0.3,
    model_type='PC-Hazard',
    local_epochs=2,
    global_epochs=2,
    learning_rate=0.01,
    batch_size=32,
    random_seed=42,
    # Augmentation parameters
    latent_num=10,    # Dimension of latent space
    hidden_num=30,    # Dimension of hidden layer
    alpha=1.0,        # Weight for KL divergence
    beta=1.0,         # Weight for conditional loss
    k=0.5            # Augmentation ratio (0 < k <= 1)
)

# Initialize and run with data augmentation
runner = FSARunner(config)
results = runner.run(
    client_data,
    type='raw_aug',
    aug_method='MVAEC'  # or 'MVAES'
)
```

#### Available Augmentation Methods

1. **MVAEC (Multi-task Variational Autoencoder at Each Client)**
   - Each client generates augmented data using its own data
   - Uses a variational autoencoder trained on uncensored samples
   - Maintains data privacy as no data is shared between clients
   - Suitable for scenarios with strong privacy requirements
   - Augmentation ratio (k) controls the amount of generated data

2. **MVAES (Multi-task Variational Autoencoder at the Server)**
   - Collects augmented data from all clients at the server
   - Redistributes the augmented data to clients
   - May improve data diversity across clients
   - Requires more communication overhead
   - Useful when clients have limited local data

#### Augmentation Process

1. **Data Preparation**
   - Only uncensored samples are used for training the VAE
   - Each client must have at least 10 samples
   - Each client must have at least one uncensored sample

2. **Model Training**
   - Uses a variational autoencoder with configurable architecture
   - Latent space dimension can be adjusted (default: 10)
   - Hidden layer dimension can be configured (default: 30)
   - KL divergence weight (alpha) controls the trade-off between reconstruction and regularization
   - Conditional loss weight (beta) controls the importance of survival time prediction

3. **Data Generation**
   - Generates new samples in the latent space
   - Maintains the statistical properties of the original data
   - Preserves the relationship between features and survival time
   - Augmentation ratio (k) determines the number of generated samples

#### Usage Considerations

- Choose MVAEC when:
  - Privacy is a primary concern
  - Clients have sufficient local data
  - Communication overhead should be minimized

- Choose MVAES when:
  - Data diversity is important
  - Clients have limited local data
  - Communication overhead is acceptable

- Parameter Tuning:
  - Adjust latent_num and hidden_num based on data complexity
  - Modify alpha and beta to control the balance between reconstruction and regularization
  - Set k according to the desired amount of augmented data

## Project Structure

- `core/`: Core components including runner implementation and model definitions
  - `runner.py`: Main federated learning runner implementation
  - `config.py`: Configuration management
- `data/`: Data processing components:
  - `generator.py`: Simulated data generation
  - `loader.py`: Real-world data loading
  - `splitter.py`: Data partitioning utilities
- `utils/`: Helper functions and utilities

## License

This project is licensed under the MIT License - see the LICENSE file for details. 